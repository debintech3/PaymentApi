package com.rabo.payment.initiatepayment;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;

import com.rabo.payment.initiatepayment.impl.PaymentInitiationServiceImpl;
import com.rabo.payment.initiatepayment.model.PaymentAcceptedResponse;
import com.rabo.payment.initiatepayment.model.PaymentInitiationRequest;

import junit.framework.Assert;

import org.powermock.modules.junit4.PowerMockRunner;

@RunWith(PowerMockRunner.class)


public class PaymentInitiationServiceImplTest {

	@InjectMocks
	private PaymentInitiationServiceImpl paymentInitiationServiceImpl;

	
	@Test
	public void initiatePaymentTest() throws Exception {
		
		PaymentAcceptedResponse paymentAcceptedResponse  = paymentInitiationServiceImpl.initiatePayment(preparePaymentInitiationRequest());
		Assert.assertNotNull(paymentAcceptedResponse);
		

	}

	/**
	 * Prepare PaymentInitiationRequest
	 * @return
	 */
	private PaymentInitiationRequest preparePaymentInitiationRequest() {
		PaymentInitiationRequest paymentInitiationRequest = new PaymentInitiationRequest();
		paymentInitiationRequest.setAmount("2");
		paymentInitiationRequest.setCreditorIBAN("NL94ABNA1008270121");
		paymentInitiationRequest.setDebtorIBAN("NL02RABO7134384551");
		paymentInitiationRequest.setCurrency("USD");
		paymentInitiationRequest.setEndToEndId("123");
		return paymentInitiationRequest;
	}
	
	

}
