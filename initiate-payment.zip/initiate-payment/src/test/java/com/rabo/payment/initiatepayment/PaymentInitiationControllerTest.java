package com.rabo.payment.initiatepayment;

import static org.junit.Assert.*;

import java.util.UUID;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.rabo.payment.initiatepayment.constants.PaymentConstant;
import com.rabo.payment.initiatepayment.controller.PaymentInitiationController;
import com.rabo.payment.initiatepayment.interceptor.PaymentServiceInterceptor;
import com.rabo.payment.initiatepayment.interfaces.PaymentInitiationService;
import com.rabo.payment.initiatepayment.model.PaymentAcceptedResponse;
import com.rabo.payment.initiatepayment.model.PaymentInitiationRequest;
import com.rabo.payment.initiatepayment.model.TransactionStatus;

@RunWith(SpringRunner.class)
@WebMvcTest(value = PaymentInitiationController.class)

public class PaymentInitiationControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private PaymentInitiationService paymentInitiationService;
	

	@MockBean
	PaymentServiceInterceptor paymentServiceInterceptor;
	
	@Before
	public void setUp() throws Exception {
		Mockito.doCallRealMethod().when(paymentServiceInterceptor).preHandle(Mockito.any(), Mockito.any(), Mockito.any());
	}
	/**
	 * Test case for initiatePaymentTest
	 * 
	 * @throws Exception
	 */
	@Test
	public void initiatePaymentTest() throws Exception {

		// Preparing the dummy response

		Mockito.when(paymentInitiationService.initiatePayment(Mockito.anyObject()))
				.thenReturn(preparePaymentAcceptedResponse());

		RequestBuilder requestBuilder = MockMvcRequestBuilders
				.post(PaymentConstant.V1 + PaymentConstant.INITIATE_PAYMENT)
				.accept(MediaType.APPLICATION_JSON)
				.header("X-Request-Id", "123")
				.header("Signature-Certificate", "2345")
				.header("Signature", "567")
				.content(asJsonString(preparePaymentInitiationRequest()))
				.contentType(MediaType.APPLICATION_JSON);				
				
		//.andExpect(MockMvcResultMatchers.status().isCreated());

		MvcResult result = mockMvc.perform(requestBuilder).andExpect(MockMvcResultMatchers.status().isCreated()).andReturn();
		MockHttpServletResponse response = result.getResponse();
		assertEquals(HttpStatus.CREATED.value(), response.getStatus());
	}

	/**
	 * Prepare PaymentAcceptedResponse
	 * @return
	 */
	private PaymentAcceptedResponse preparePaymentAcceptedResponse() {
		PaymentAcceptedResponse paymentAcceptedResponse = new PaymentAcceptedResponse();
		paymentAcceptedResponse.setStatus(TransactionStatus.ACCEPTED);
		paymentAcceptedResponse.setPaymentId(UUID.randomUUID());
		return paymentAcceptedResponse;
	}

	/**
	 * Prepare PaymentInitiationRequest
	 * @return
	 */
	private PaymentInitiationRequest preparePaymentInitiationRequest() {
		PaymentInitiationRequest paymentInitiationRequest = new PaymentInitiationRequest();
		paymentInitiationRequest.setAmount("2");
		paymentInitiationRequest.setCreditorIBAN("NL94ABNA1008270121");
		paymentInitiationRequest.setDebtorIBAN("NL02RABO7134384551");
		paymentInitiationRequest.setCurrency("USD");
		paymentInitiationRequest.setEndToEndId("123");
		return paymentInitiationRequest;
	}

	public static String asJsonString(final Object obj) {
		try {
			return new ObjectMapper().writeValueAsString(obj);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

}
