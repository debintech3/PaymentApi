package com.rabo.payment.initiatepayment.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.rabo.payment.initiatepayment.model.ErrorReasonCode;
import com.rabo.payment.initiatepayment.model.PaymentRejectedResponse;
import com.rabo.payment.initiatepayment.model.TransactionStatus;

@ControllerAdvice
public class PayementExceptionHandler extends ResponseEntityExceptionHandler {
	private final Logger LOGGER = (Logger) LoggerFactory.getLogger(this.getClass());
	
	/**
	 * The common method to handle all the request like header validation, bean validation and other error
	 * @param ex
	 * @param request
	 * @return 
	 */
	@ExceptionHandler(Exception.class)
	protected ResponseEntity<Object> handleRequest(Exception ex, WebRequest request) {
		
		LOGGER.info("PayementExceptionHandler::handleRequest()");		

		HttpHeaders headers = new HttpHeaders();
		headers.add("Signature", request.getHeader("Signature"));
		headers.add("Signature-Certificate", request.getHeader("Signature-Certificate"));
		HttpStatus httpStatus = null;

		PaymentRejectedResponse paymentRejectedResponse = new PaymentRejectedResponse();
		if (ex.getMessage().equalsIgnoreCase(ErrorReasonCode.LIMIT_EXCEEDED.toString())) {//tested
			paymentRejectedResponse.setReason("Amount limit exceeded");
			paymentRejectedResponse.setReasonCode(ErrorReasonCode.LIMIT_EXCEEDED);
			paymentRejectedResponse.setStatus(TransactionStatus.REJECTED);
			httpStatus = HttpStatus.UNPROCESSABLE_ENTITY;
		} else if (ex.getMessage().equalsIgnoreCase(ErrorReasonCode.UNKNOWN_CERTIFICATE.toString())) {
			paymentRejectedResponse.setReason("Certification is un known");
			paymentRejectedResponse.setReasonCode(ErrorReasonCode.UNKNOWN_CERTIFICATE);
			paymentRejectedResponse.setStatus(TransactionStatus.REJECTED);
			httpStatus = HttpStatus.UNPROCESSABLE_ENTITY;
		} else if (ex.getMessage().equalsIgnoreCase(ErrorReasonCode.INVALID_SIGNATURE.toString())) {
			paymentRejectedResponse.setReason("Signature is invalid");
			paymentRejectedResponse.setReasonCode(ErrorReasonCode.INVALID_SIGNATURE);
			paymentRejectedResponse.setStatus(TransactionStatus.REJECTED);
			httpStatus = HttpStatus.UNPROCESSABLE_ENTITY;
		}  else if (ex.getMessage().equalsIgnoreCase(ErrorReasonCode.GENERAL_ERROR.toString())) {
			paymentRejectedResponse.setReason("There is some internal server error");
			paymentRejectedResponse.setReasonCode(ErrorReasonCode.GENERAL_ERROR);
			paymentRejectedResponse.setStatus(TransactionStatus.REJECTED);
			httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
		}

		return buildResponseEntity(paymentRejectedResponse, headers, httpStatus);

	}

	private ResponseEntity<Object> buildResponseEntity(PaymentRejectedResponse paymentRejectedResponse,
			HttpHeaders headers, HttpStatus status) {
		return new ResponseEntity<>(paymentRejectedResponse, headers, status);

	}

	/**
	 * Error handle for @Valid
	 */
	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		LOGGER.info("PayementExceptionHandler::handleMethodArgumentNotValid()");

		headers.add("Signature", request.getHeader("Signature"));
		headers.add("Signature-Certificate", request.getHeader("Signature-Certificate"));		

		PaymentRejectedResponse paymentRejectedResponse = new PaymentRejectedResponse();

		paymentRejectedResponse.setReason("The request is invalid.Please provide correct value");
		paymentRejectedResponse.setReasonCode(ErrorReasonCode.INVALID_REQUEST);
		paymentRejectedResponse.setStatus(TransactionStatus.REJECTED);
		status = HttpStatus.BAD_REQUEST;

		return new ResponseEntity<>(paymentRejectedResponse, headers, status);

	}

}