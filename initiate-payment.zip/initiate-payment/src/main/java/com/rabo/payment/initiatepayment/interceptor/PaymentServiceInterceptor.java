package com.rabo.payment.initiatepayment.interceptor;

import java.io.ByteArrayInputStream;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.Signature;
import java.security.SignatureException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

@Component
public class PaymentServiceInterceptor implements HandlerInterceptor {
	private final Logger LOGGER = (Logger) LoggerFactory.getLogger(this.getClass());

	String strPk;
	String realPK;

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {

		LOGGER.info("PaymentServiceInterceptor::Pre Handle method is Calling");

		verifyIncomingCertificateSignatue(request);

		return true;
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {

		System.out.println("Post Handle method is Calling");
	}

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler,
			Exception exception) throws Exception {

		System.out.println("Request and Response is completed");
	}

	/**
	 * This method is to validate unknown certificates and verify the
	 * X509Certificate using the SHA256WithRSA
	 * 
	 * @param request
	 * @throws Exception
	 */
	public void verifyIncomingCertificateSignatue(HttpServletRequest request) throws Exception {
		LOGGER.info("PaymentServiceInterceptor::verifyIncomingCertificateSignatue()");
		X509Certificate x509Certificate = getUserCertificate(request);

		try {

			if (!x509Certificate.getSubjectDN().getName().startsWith("Sandbox-TPP")) {
				throw new Exception("UNKNOWN_CERTIFICATE");
			}

			Signature signature = Signature.getInstance("SHA256WithRSA");
			signature.initVerify(x509Certificate.getPublicKey());

			if (signature.verify(x509Certificate.getSignature())) {
				LOGGER.info("PaymentServiceInterceptor::verifyIncomingCertificateSignatue():: Accepted");
			} else {				
				LOGGER.info("PaymentServiceInterceptor::verifyIncomingCertificateSignatue():: Not verified");
				throw new Exception("INVALID_SIGNATURE");
			}

		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (InvalidKeyException e) {
			e.printStackTrace();
		} catch (SignatureException e) {
			e.printStackTrace();
		}
	}

	/**
	 * This method to create X509Certificate based on the Signature-Certificate
	 * from header
	 * 
	 * @param request
	 * @return
	 * @throws Exception
	 */
	private static X509Certificate getUserCertificate(HttpServletRequest request) throws Exception {
		CertificateFactory certFactory = CertificateFactory.getInstance("X.509");
		ByteArrayInputStream bytes = new ByteArrayInputStream(request.getHeader("Signature-Certificate").getBytes());
		return (X509Certificate) certFactory.generateCertificate(bytes);
	}

}
