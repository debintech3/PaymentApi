package com.rabo.payment.initiatepayment.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import lombok.Data;

@ApiModel(description = "Created response. The status shall always be 'Rejected'")
@Data
public class PaymentRejectedResponse {
	@JsonProperty("status")
	private TransactionStatus status;

	@JsonProperty("reason")
	private String reason = null;

	@JsonProperty("reasonCode")
	private ErrorReasonCode reasonCode;

}
