package com.rabo.payment.initiatepayment.interfaces;

import org.springframework.stereotype.Service;

import com.rabo.payment.initiatepayment.model.PaymentAcceptedResponse;
import com.rabo.payment.initiatepayment.model.PaymentInitiationRequest;


public interface PaymentInitiationService {
	
	public PaymentAcceptedResponse initiatePayment(PaymentInitiationRequest paymentInitiationRequest) throws Exception;
	

}
