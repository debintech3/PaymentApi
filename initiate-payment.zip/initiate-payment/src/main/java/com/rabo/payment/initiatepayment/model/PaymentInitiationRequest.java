package com.rabo.payment.initiatepayment.model;



import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.*;

import javax.validation.constraints.NotNull;


/**
 * The payment initiation request model
 */
@ApiModel(description = "The payment initiation request model")

@Data
@Valid
public class PaymentInitiationRequest {

	@Pattern(regexp = "[A-Z]{2}[0-9]{2}[a-zA-Z0-9]{1,30}", message= "INVALID_REQUEST")
	@JsonProperty("debtorIBAN")
	@NotNull(message="DebtorIBAN can not be null")
	@NotEmpty(message="DebtorIBAN can not be empty")
	private String debtorIBAN;

	@Pattern(regexp = "[A-Z]{2}[0-9]{2}[a-zA-Z0-9]{1,30}", message="INVALID_REQUEST")
	@NotNull(message="CreditorIBAN can not be null")
	@NotEmpty(message="CreditorIBAN can not be empty")
	@JsonProperty("creditorIBAN")
	private String creditorIBAN;

	@Pattern(regexp = "-?[0-9]+(\\.[0-9]{1,3})?", message="INVALID_REQUEST")
	@NotNull(message="Amount can not be null")
	@NotEmpty(message = "Amount can not be empty")
	@JsonProperty("amount")
	private String amount;

	@Pattern(regexp = "[A-Z]{3}", message="INVALID_REQUEST")	
	@JsonProperty("currency")
	private String currency;

	@JsonProperty("endToEndId")
	private String endToEndId;

	

}
