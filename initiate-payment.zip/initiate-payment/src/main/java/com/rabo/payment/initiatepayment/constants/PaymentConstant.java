package com.rabo.payment.initiatepayment.constants;

public class PaymentConstant {
	
	public final static  String V1 = "/v1.0.0";
	public final static  String INITIATE_PAYMENT = "/initiate-payment";
	

}
