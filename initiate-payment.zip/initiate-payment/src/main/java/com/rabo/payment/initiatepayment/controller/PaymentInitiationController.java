package com.rabo.payment.initiatepayment.controller;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rabo.payment.initiatepayment.constants.PaymentConstant;
import com.rabo.payment.initiatepayment.interfaces.PaymentInitiationService;
import com.rabo.payment.initiatepayment.model.PaymentAcceptedResponse;
import com.rabo.payment.initiatepayment.model.PaymentInitiationRequest;


@RestController
@RequestMapping(PaymentConstant.V1)
public class PaymentInitiationController {
	private final Logger LOGGER = (Logger) LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	PaymentInitiationService paymentInitiationService;

	@PostMapping(PaymentConstant.INITIATE_PAYMENT)
	ResponseEntity<PaymentAcceptedResponse> intiatePayment(@RequestHeader("X-Request-Id")  String value, 
			@RequestHeader("Signature-Certificate") String certificates, 
			@RequestHeader("Signature") String signature, @Valid @RequestBody PaymentInitiationRequest paymentInitiationRequest ) throws Exception {

		LOGGER.info("PaymentInitiationController::intiatePayment");
	    
	    PaymentAcceptedResponse paymentAcceptedResponse = paymentInitiationService.initiatePayment(paymentInitiationRequest);
	    HttpHeaders headers = new HttpHeaders();
	    headers.add("Signature", signature);
		headers.add("Signature-Certificate", certificates);           
        return ResponseEntity.status(HttpStatus.CREATED).headers(headers).body(paymentAcceptedResponse);
		
	}	
	
}
