package com.rabo.payment.initiatepayment.impl;

import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.rabo.payment.initiatepayment.interfaces.PaymentInitiationService;
import com.rabo.payment.initiatepayment.model.ErrorReasonCode;
import com.rabo.payment.initiatepayment.model.PaymentAcceptedResponse;
import com.rabo.payment.initiatepayment.model.PaymentInitiationRequest;
import com.rabo.payment.initiatepayment.model.TransactionStatus;

@Service
public class PaymentInitiationServiceImpl implements PaymentInitiationService {

	private final Logger LOGGER = (Logger) LoggerFactory.getLogger(this.getClass());
	
	/**
	 * This method used to initiate the payment and return the response with status and header
	 * @throws Exception 
	 */
	@Override
	public PaymentAcceptedResponse initiatePayment(PaymentInitiationRequest paymentInitiationRequest) throws Exception {
		LOGGER.info("This is an INFO log");
		PaymentAcceptedResponse paymentAcceptedResponse = new PaymentAcceptedResponse();

		if (isAmountLimitExceed(paymentInitiationRequest)) {
			throw new Exception(ErrorReasonCode.LIMIT_EXCEEDED.toString());
		} else {
			paymentAcceptedResponse.setStatus(TransactionStatus.ACCEPTED);
			paymentAcceptedResponse.setPaymentId(UUID.randomUUID());
		}
		return paymentAcceptedResponse;		

	}

	private boolean isAmountLimitExceed(PaymentInitiationRequest paymentInitiationRequest) throws Exception {
		try {
			int sum = sumDebtorIBAN(paymentInitiationRequest.getDebtorIBAN());
			int length = paymentInitiationRequest.getDebtorIBAN().length();
			//int length = 43;

			if ((Integer.parseInt(paymentInitiationRequest.getAmount()) > 0 ) && (sum % length == 0)) {			
				return true;
			}				

		} catch(Exception ex) {
			ex.printStackTrace();
			throw new Exception(ErrorReasonCode.GENERAL_ERROR.toString());
		}

		return false;					
	}

	public int sumDebtorIBAN(String debtorIBAN) {
		return debtorIBAN.chars().mapToObj(i -> (char) i).filter(Character::isDigit)
				.mapToInt(Character::getNumericValue).sum();
	}	

}

