package com.rabo.payment.initiatepayment.model;

import java.util.UUID;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import lombok.Data;

@ApiModel(description = "Created response. The status shall always be 'Accepted'")
@Data
@Validated
public class PaymentAcceptedResponse {

	@JsonProperty("paymentId")
	private UUID paymentId;

	@JsonProperty("status")
	private TransactionStatus status;

}
